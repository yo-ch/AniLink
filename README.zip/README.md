# MyAnilist
Chrome extension that adds a link to the equivalent MyAnimeList page of Anilist anime/manga pages, along with the equivalent MAL score. 

Useful for when Anilist is missing information.
